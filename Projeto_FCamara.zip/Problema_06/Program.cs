﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problema_06
{
    class Program
    {
        static void Main(string[] args)
        {
            decimal _altura = 0;
            decimal _base = 0m;

            Console.Write("Insira a altura do retangulo: ");
            _altura = Decimal.Parse(Console.ReadLine());
            Console.Write("Insira a base do retangulo: ");
            _base = Decimal.Parse(Console.ReadLine());

            Retangulo ret = new Retangulo(_altura, _base);

            Console.Write("\nInsira a area em M2 dos pisos: ");
            decimal pisos = Decimal.Parse(Console.ReadLine());
            decimal pisosNecessarios = Math.Truncate(ret.CalcularArea() / pisos);
            Console.Write("A quantidade de pisos necessária é: {0}\n", pisosNecessarios);

            Console.Write("\nInsira o tamanho dos rodapés: ");
            decimal rodapes = Decimal.Parse(Console.ReadLine());
            decimal rodapesNecessarios = Math.Truncate(ret.CalcularPerimetro() / rodapes);
            Console.WriteLine("A quantidade de rodapés necessária é: {0}\n", rodapesNecessarios);
        }
    }
}
