﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problema_06
{
    class Retangulo
    {
        private decimal alturaDoRetangulo;
        private decimal baseDoRetangulo;

        public Retangulo(decimal alturaDoRetangulo, decimal baseDoRetangulo)
        {
            this.alturaDoRetangulo = alturaDoRetangulo;
            this.baseDoRetangulo = baseDoRetangulo;
        }

        public void MudarValorDaAltura(decimal novoValor)
        {
            alturaDoRetangulo = novoValor;
        }

        public decimal BuscarValorDaAltura()
        {
            return alturaDoRetangulo;
        }

        public decimal CalcularArea ()
        {
            return baseDoRetangulo * alturaDoRetangulo;
        }

        public decimal CalcularPerimetro()
        {
            return (baseDoRetangulo + alturaDoRetangulo) * 2;
        }
    }
}
