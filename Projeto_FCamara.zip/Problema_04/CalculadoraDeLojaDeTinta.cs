﻿    using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problema_04
{
    class CalculadoraDeLojaDeTinta
    {
        static void Main(string[] args)
        {
            decimal capacidadeDaLata = 18;
            decimal valorDaLata = 80.0m;

            decimal areaEmM2 = 0.0m;

            Console.Write("Insira o tamanho da área a ser pintada em metros quadrados: ");
            areaEmM2 = Decimal.Parse(Console.ReadLine());

            decimal litrosNecessarios = areaEmM2 / 3.0m;
            decimal latasNecessarias = Math.Ceiling(litrosNecessarios / capacidadeDaLata);
            decimal valor = latasNecessarias * valorDaLata;

            Console.WriteLine("\nLatas necessárias: {0} \nValor: {1}\n", latasNecessarias, Math.Round(valor, 2));
        }
    }
}
