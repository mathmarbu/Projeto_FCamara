﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problema_02
{
    class NumerosPrimos
    {


        public static bool TestarPrimalidade(int num)
        {
            for (int i = num - 1; i > 1; i--)
            {
                if (num % i == 0)
                {
                    return false;
                }
            }

            return true;
        }

    }
}
