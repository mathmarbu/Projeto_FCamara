﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problema_02
{
    class Program
    {
        static void Main(string[] args)
        {
            int valorInicial = 0;
            int valorFinal = 0;

            Console.Write("Insira o primeiro valor: ");
            valorInicial = Int32.Parse(Console.ReadLine());
            Console.Write("Insira o segundo valor: ");
            valorFinal = Int32.Parse(Console.ReadLine());

            if (valorInicial < 2 || valorInicial > valorFinal)
            {
                Console.Write("\nValores Inválidos!");
            }
            else
            {
                Console.Write("\nOs primos são: ");

                for (int i = valorInicial; i <= valorFinal; i++)
                {
                    if (NumerosPrimos.TestarPrimalidade(i))
                        Console.Write("{0} ", i);
                }
            }

            Console.WriteLine("\n");
        }
    }
}

