﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto_FCamara
{

    public class Funcionario
    {
        public string Nome { get; set; }
        public decimal SalarioInicial { get; set; }

        public Funcionario(string nome, decimal salarioInicial)
        {
            Nome = nome;
            SalarioInicial = salarioInicial;
        }

        public decimal CalcularSalario(int ano)
        {
            decimal percentual = (decimal)0.015;

            if (ano == 2005)
            {
                return SalarioInicial;
            }
            else if (ano == 2006)
            {
                return SalarioInicial + SalarioInicial * percentual;
            }
            else if (ano > 2006)
            {
                decimal salarioAtualizado = SalarioInicial;

                for (int i = 2006; i <= ano; i++)
                {
                    salarioAtualizado += salarioAtualizado * percentual;
                    percentual *= 2;
                }

                return salarioAtualizado;
            }
            else
            {
                Console.WriteLine("O ano precisa ser maior que 2005!\n");
                return 0;
            }
        }
    }

}
