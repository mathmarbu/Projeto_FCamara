﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto_FCamara
{
    class Program
    {
        static void Main(string[] args)
        {
            Funcionario func = new Funcionario("Matheus Bueno", 1000.00m);
            Console.WriteLine("O salário calculado é : {0} \n", Math.Round(func.CalcularSalario(2018), 2));
        }
    }
}
