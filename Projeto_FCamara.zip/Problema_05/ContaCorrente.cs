﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problema_05
{
    public class ContaCorrente
    {
        // Os atributos privados são criados automaticamente ao se criar propriedades
        public int NumeroDaConta { get; set; }
        public string NomeDoCorrentista { get; set; }
        public decimal Saldo { get; set; }

        public ContaCorrente(int numeroDaConta, string nomeDoCorrentista, decimal saldo = 0)
        {
            // Não é necessário a referência "this", os atributos são acessados pelas propriedades que diferem, em nome, dos parmetros do construtor
            NumeroDaConta = numeroDaConta;
            NomeDoCorrentista = nomeDoCorrentista;
            Saldo = saldo;
        }

        public void AlterarNome(string novoNome)
        {
            NomeDoCorrentista = novoNome;
        }

        public void Deposito(decimal valor)
        {
            Saldo += valor;
        }

        public decimal Saque(decimal valor)
        {
            if (valor <= Saldo)
            {
                Saldo -= valor;
                return valor;
            }
            else
            {
                Console.WriteLine("\nSaldo insuficiente!\n");
                return 0;
            }

        }

    }
}
