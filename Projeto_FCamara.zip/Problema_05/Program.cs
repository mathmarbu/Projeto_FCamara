﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problema_05
{
    class Program
    {
        static void Main(string[] args)
        {
            ContaCorrente conta = new ContaCorrente(100000, "Matheus Bueno");
            conta.AlterarNome("Matheus Martins Bueno");
            conta.Deposito(1000.00m);
            conta.Saque(80.00m);
            Console.WriteLine("O saldo final é: R$ {0}\n", conta.Saldo, 2);
        }
    }
}
