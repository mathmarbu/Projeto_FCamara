﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problema_03
{
    class CalculadoraDeSalario
    {
        static void Main(string[] args)
        {
            decimal horasTrabalhadas = 0;
            decimal salarioMinimo = 0;

            Console.Write("Insira a quantidade de horas trabalhadas: ");
            horasTrabalhadas = Decimal.Parse(Console.ReadLine());
            Console.Write("Insira o valor do salário mínimo: ");
            salarioMinimo = Decimal.Parse(Console.ReadLine());

            decimal valorDaHora = salarioMinimo * 0.1m;
            decimal imposto = 0.03m;
            decimal salarioBruto = valorDaHora * horasTrabalhadas;
            decimal salarioLiquido = salarioBruto -= salarioBruto * imposto;

            Console.WriteLine("\nO valor do salario a receber é: R${0}\n", Math.Round(salarioLiquido, 2));
        }
    }
}
